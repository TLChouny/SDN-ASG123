const bcrypt = require('bcryptjs'); // Đổi bcrypt thành bcryptjs như bạn dùng
const jwt = require('jsonwebtoken');
const User = require('../models/userModel');

// Đăng ký User
const registerUser = async (req, res) => {
  try {
    const { username, password, role } = req.body;

    if (await User.findOne({ username })) {
      return res.status(400).json({ error: 'Username already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, password: hashedPassword, role });
    await newUser.save();

    res.status(201).json({
      message: 'User created successfully',
      user: { id: newUser._id, username, role },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Đăng nhập User
const loginUser = async (req, res) => {
  const { username, password } = req.body; // Nếu schema dùng username thì đổi thành username

  try {
    // Kiểm tra user
    const user = await User.findOne({ username }); // Nếu schema dùng username thì đổi thành { username: email }
    if (!user) {
      return res.status(401).json({ error: 'Invalid user or password' });
    }

    // Kiểm tra password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid user or password' });
    }

    // Tạo access token
    const accessToken = jwt.sign(
      { _id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '15m' }
    );

    // Tạo refresh token
    const refreshToken = jwt.sign(
      { _id: user._id },
      process.env.JWT_REFRESH_SECRET,
      { expiresIn: '7d' }
    );

    // Lưu refresh token vào database
    user.refreshToken = refreshToken;
    await user.save();

    // Trả về response
    res.status(200).json({
      accessToken,
      refreshToken,
      user: { _id: user._id, username: user.username, role: user.role }, // Nếu dùng username thì đổi email thành username
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Làm mới token
const refreshToken = async (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(401).json({ error: 'Refresh token is required' });
  }

  try {
    // Tìm user với refresh token
    const user = await User.findOne({ refreshToken });
    if (!user) {
      return res.status(403).json({ error: 'Invalid refresh token' });
    }

    // Xác minh refresh token
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    if (decoded._id !== user._id.toString()) {
      return res.status(403).json({ error: 'Invalid refresh token' });
    }

    // Tạo access token mới
    const newAccessToken = jwt.sign(
      { _id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '15m' }
    );

    res.status(200).json({ accessToken: newAccessToken });
  } catch (err) {
    console.error('Refresh token error:', err);
    return res.status(403).json({ error: 'Invalid or expired refresh token' });
  }
};

// Lấy danh sách User
const getUsers = async (req, res) => {
  try {
    const users = await User.find().select('_id username role'); // Đổi id thành _id
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Cập nhật User
const updateUser = async (req, res) => {
  try {
    const { username, password, role } = req.body;
    const userId = req.params.id;
    const requesterRole = req.user.role; // Lấy role từ req.user thay vì req.params

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Kiểm tra quyền hạn
    if (requesterRole === 'admin' && (role === 'admin' || role === 'manager')) {
      return res.status(403).json({ error: 'Admin cannot assign admin or manager role' });
    }

    if (username) user.username = username;
    if (password) user.password = await bcrypt.hash(password, 10);
    if (role) user.role = role;

    await user.save();
    res.json({ message: 'User updated successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Xoá User
const deleteUser = async (req, res) => {
  try {
    const userId = req.params.id;
    const requesterRole = req.user.role; // Lấy role từ req.user

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Logic kiểm tra quyền xóa
    if (requesterRole === 'manager' && user.role === 'manager') {
      return res.status(403).json({ error: 'Manager cannot delete another manager' });
    }
    if (requesterRole === 'admin' && (user.role === 'admin' || user.role === 'manager')) {
      return res.status(403).json({ error: 'Admin cannot delete admin or manager' });
    }

    await User.findByIdAndDelete(userId);
    res.json({ message: 'User deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Export tất cả các hàm
module.exports = { registerUser, loginUser, refreshToken, getUsers, updateUser, deleteUser };