const mongoose = require('mongoose');
const Category = require('../models/category');
const Product = require('../models/product');

// Hàm định dạng response để _id lên đầu
const formatResponse = (data) => {
  if (Array.isArray(data)) {
    return data.map(item => ({
      _id: item._id,
      name: item.name,
      description: item.description,
      createdBy: item.createdBy,
      createdAt: item.createdAt,
      updatedBy: item.updatedBy,
      updatedAt: item.updatedAt,
      __v: item.__v,
      ...(item.product && { product: item.product }) // Thêm product nếu có
    }));
  }
  return {
    _id: data._id,
    name: data.name,
    description: data.description,
    createdBy: data.createdBy,
    createdAt: data.createdAt,
    updatedBy: data.updatedBy,
    updatedAt: data.updatedAt,
    __v: data.__v,
    ...(data.product && { product: data.product }) // Thêm product nếu có
  };
};

// Create a new category
exports.createCategory = async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'manager') {
      return res.status(403).json({ error: 'Access denied, only admin can create category' });
    }

    let result;
    if (Array.isArray(req.body)) {
      const categoriesWithUser = req.body.map(category => ({
        ...category,
        createdBy: req.user._id
      }));
      result = await Category.insertMany(categoriesWithUser);
      result = await Category.find({ _id: { $in: result.map(r => r._id) } })
        .populate('createdBy', 'username email');
    } else {
      const categoryData = {
        ...req.body,
        createdBy: req.user._id
      };
      const category = new Category(categoryData);
      await category.save();
      result = await Category.findById(category._id)
        .populate('createdBy', 'username email');
    }

    const formattedResult = formatResponse(result);
    res.status(201).json(formattedResult);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get a single category
exports.getCategoryById = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ error: 'Invalid category ID' });
    }

    const category = await Category.findById(req.params.id)
      .populate('createdBy', 'username email')
      .populate('updatedBy', 'username email')
      .lean();
    
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }

    const products = await Product.find({ category: req.params.id }).lean();
    const categoryWithProducts = {
      ...category,
      product: products
    };

    console.log('Response data:', categoryWithProducts);
    const formattedResult = formatResponse(categoryWithProducts);
    res.status(200).json(formattedResult);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get all categories
exports.getCategories = async (req, res) => {
  try {
    const categories = await Category.find()
      .populate('createdBy', 'username email')
      .populate('updatedBy', 'username email');

    const formattedResult = formatResponse(categories);
    res.status(200).json(formattedResult);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Update a category
exports.updateCategory = async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'manager') {
      return res.status(403).json({ error: 'Access denied, only admin can update category' });
    }

    const updateData = {
      ...req.body,
      updatedBy: req.user._id,
      updatedAt: Date.now()
    };

    const category = await Category.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    )
      .populate('createdBy', 'username email')
      .populate('updatedBy', 'username email');

    if (!category) return res.status(404).json({ error: 'Category not found' });

    const formattedResult = formatResponse(category);
    res.status(200).json(formattedResult);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Delete a category (không cần thay đổi response vì chỉ trả về message)
exports.deleteCategory = async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'manager') {
      return res.status(403).json({ error: 'Access denied, only admin can delete category' });
    }

    const category = await Category.findByIdAndDelete(req.params.id);
    if (!category) return res.status(404).json({ error: 'Category not found' });
    res.status(200).json({ message: 'Category deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};