const mongoose = require('mongoose');
const Product = require('../models/product');

// Hàm định dạng response để _id lên đầu
const formatResponse = (data) => {
  if (Array.isArray(data)) {
    return data.map(item => ({
      _id: item._id,
      name: item.name,
      price: item.price,
      description: item.description,
      category: item.category,
      createdBy: item.createdBy,
      createdAt: item.createdAt,
      updatedBy: item.updatedBy,
      updatedAt: item.updatedAt,
      __v: item.__v
    }));
  }
  return {
    _id: data._id,
    name: data.name,
    price: data.price,
    description: data.description,
    category: data.category,
    createdBy: data.createdBy,
    createdAt: data.createdAt,
    updatedBy: data.updatedBy,
    updatedAt: data.updatedAt,
    __v: data.__v
  };
};

// Create a new product
exports.createProduct = async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'manager') {
      return res.status(403).json({ error: 'Access denied, only admin can create product' });
    }

    const productData = {
      ...req.body,
      createdBy: req.user._id
    };
    const product = new Product(productData);
    await product.save();

    // Populate thông tin category và createdBy
    const populatedProduct = await Product.findById(product._id)
      .populate('category', 'name description')
      .populate('createdBy', 'username email');

    const formattedResult = formatResponse(populatedProduct);
    res.status(201).json(formattedResult);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get all products
exports.getProducts = async (req, res) => {
  try {
    const products = await Product.find()
      .populate('category', 'name description')
      .populate('createdBy', 'username email')
      .populate('updatedBy', 'username email');

    const formattedResult = formatResponse(products);
    res.status(200).json(formattedResult);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get a single product
exports.getProductById = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ error: 'Invalid product ID' });
    }

    const product = await Product.findById(req.params.id)
      .populate('category', 'name description')
      .populate('createdBy', 'username email')
      .populate('updatedBy', 'username email');

    if (!product) return res.status(404).json({ error: 'Product not found' });

    const formattedResult = formatResponse(product);
    res.status(200).json(formattedResult);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Update a product
exports.updateProduct = async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'manager') {
      return res.status(403).json({ error: 'Access denied, only admin can update product' });
    }

    const updateData = {
      ...req.body,
      updatedBy: req.user._id,
      updatedAt: Date.now()
    };

    const product = await Product.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    )
      .populate('category', 'name description')
      .populate('createdBy', 'username email')
      .populate('updatedBy', 'username email');

    if (!product) return res.status(404).json({ error: 'Product not found' });

    const formattedResult = formatResponse(product);
    res.status(200).json(formattedResult);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Delete a product
exports.deleteProduct = async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'manager') {
      return res.status(403).json({ error: 'Access denied, only admin can delete product' });
    }

    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.status(200).json({ message: 'Product deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  createProduct: exports.createProduct,
  getProducts: exports.getProducts,
  getProductById: exports.getProductById,
  updateProduct: exports.updateProduct,
  deleteProduct: exports.deleteProduct
};