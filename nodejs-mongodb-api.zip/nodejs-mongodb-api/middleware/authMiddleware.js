const jwt = require("jsonwebtoken");

// Xác thực User
const authenticateUser = (req, res, next) => {
  const token = req.header("Authorization")?.split(" ")[1]; // Lấy token từ Header
  if (!token) return res.status(401).json({ error: "Unauthorized" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(403).json({ error: "Invalid token" });
  }
};

// Kiểm tra quyền Admin
const authorizeAdmin = (req, res, next) => {
  const user = req.user; // Lấy thông tin người dùng từ req
  if (user && user.role === 'admin' || user.role === 'manager') {
    next(); // Cho phép tiếp tục nếu là admin
  } else {
    return res.status(403).json({ error: "Forbidden: Admins only" });
  }
};

// Route lấy tất cả người dùng không cần quyền admin
const getAllUsers = (req, res) => {
  // Logic để lấy tất cả người dùng
  res.json({ message: "All users retrieved" });
};

module.exports = { authenticateUser, authorizeAdmin, getAllUsers };