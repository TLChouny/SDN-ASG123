const express = require("express");
const userController = require("../controllers/userController");
const { authenticateUser, authorizeAdmin } = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/register", userController.registerUser);
router.post("/login", userController.loginUser);
router.post('/refresh-token', userController.refreshToken);
router.get("/", userController.getUsers);
router.put("/:id", authenticateUser, authorizeAdmin, userController.updateUser);
router.delete("/:id", authenticateUser, authorizeAdmin, userController.deleteUser);

module.exports = router;
