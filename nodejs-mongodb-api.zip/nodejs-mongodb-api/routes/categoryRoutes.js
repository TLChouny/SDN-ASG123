const express = require('express');
const router = express.Router();
const categoryController = require('../controllers/categoryController');
const { authenticateUser, authorizeAdmin } = require("../middleware/authMiddleware");


router.post('/', authenticateUser, authorizeAdmin, categoryController.createCategory);
router.get('/', authenticateUser, categoryController.getCategories);
router.put('/:id', authenticateUser, authorizeAdmin, categoryController.updateCategory);
router.delete('/:id', authenticateUser, authorizeAdmin, categoryController.deleteCategory);
router.get('/:id', authenticateUser, categoryController.getCategoryById);

module.exports = router;