const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const { authenticateUser, authorizeAdmin } = require("../middleware/authMiddleware");


router.post('/', authenticateUser, authorizeAdmin, productController.createProduct);
router.get('/', authenticateUser, productController.getProducts);
router.put('/:id', authenticateUser, authorizeAdmin, productController.updateProduct);
router.delete('/:id', authenticateUser, authorizeAdmin, productController.deleteProduct);
router.get('/:id', authenticateUser, productController.getProductById);

module.exports = router;